#{{uc_id}}{
  min-height:1px;
  overflow: hidden;
  position: relative;
}

#{{uc_id}} .uc-items-wrapper{
  display: flex;
  will-change: transform;
  transform: translateX({{offset}}px) translateZ(0);
}

#{{uc_id}} .ue-scroll-marquee-item{
  position: relative;
  z-index: 2;
  flex: 0 0 auto;
  overflow: hidden;
}

#{{uc_id}} .ue-scroll-marquee-item-img,
#{{uc_id}} .ue-scroll-marquee-item-video{
  display: block;
  {% if width_type == "justified" %}
  width: auto;
  {% endif %}
}

#{{uc_id}} .ue-scroll-marquee-item-video-cover{
  cursor: pointer;
  position: relative;
}


#{{uc_id}} .ue-scroll-marquee-item-video-play-icon{
  position: absolute;
  margin: auto;
  cursor: pointer;
  z-index: 1;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: center;
}

#{{uc_id}} .ue-scroll-marquee-item.ue-scroll-marquee-item-video-active .ue-scroll-marquee-item-video-cover,
#{{uc_id}} .ue-scroll-marquee-item.ue-scroll-marquee-item-video-active .ue-scroll-marquee-item-video-play-icon{
  display: none;
}

#{{uc_id}} .ue-scroll-marquee-item-content{
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 100%;
  transition: all .3s ease;
  opacity: 0;
  z-index: 2;
}

#{{uc_id}} .ue-scroll-marquee-item-bg{
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 100%;
  transition: all .3s ease;
  opacity: 0;
  z-index: 1;
}

#{{uc_id}} .ue-scroll-marquee-item:hover .ue-scroll-marquee-item-content{
  opacity: 1;
}

#{{uc_id}} .ue-scroll-marquee-item:hover .ue-scroll-marquee-item-bg{
  opacity: 1;
}