{# twig vars #}{##}
{% set dataVideoLinkAttr %}
  {% if item.video_type == "self" %}{{item.video_link|ucsafe|raw}}{% elseif item.video_type == "youtube" %}{{item.video_id_youtube|ucsafe|raw}}{% elseif item.video_type == "vimeo" %}{{item.video_id_vimeo|ucsafe|raw}}{% endif %}
{% endset %}
{# end twig vars #}{##}

<div id="{{item.item_id}}" class="ue-scroll-marquee-item">
  {% if item.item_source == "image" %}
    <img class="ue-scroll-marquee-item-img" src="{{item.image}}" {{item.image_attributes|ucsafe|raw}} />
    {% if show_overlay == "true" %}<div class="ue-scroll-marquee-item-bg"></div>{% endif %}
    <a class="ue-scroll-marquee-item-content" {% if item.link is not empty %}href="{{item.link}}" {{item.link_html_attributes|ucsafe|raw}}{% endif %}>
      {% if show_title == "true" and item.title is not empty %}<div class="ue-scroll-marquee-item-content-title">{{item.title}}</div>{% endif %}
      {% if show_text == "true" and item.text is not empty %}<div class="ue-scroll-marquee-item-content-text">{{item.text|ucsafe|raw}}</div>{% endif %}
    </a>  
  {% elseif item.item_source == "video" %}
    <img class="ue-scroll-marquee-item-img ue-scroll-marquee-item-video-cover" src="{{item.video_poster}}" {{item.video_poster_attributes|ucsafe|raw}} data-type="{{item.video_type}}" data-link="{{dataVideoLinkAttr}}" data-title="{{item.title}}"/>
    {% if show_play_icon == "true" %}<div class="ue-scroll-marquee-item-video-play-icon">{{play_icon_html|ucsafe|raw}}</div>{% endif %}
  {% elseif item.item_source == "template" %}
    {{putElementorTemplate(item.template_templateid)}}
  {% endif %}
</div>