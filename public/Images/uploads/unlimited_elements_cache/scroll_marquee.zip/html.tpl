<div id="{{uc_id}}" class="ue-scroll-marquee {{uc_filtering_addclass}}" {{uc_filtering_attributes|raw}}>
  <div class="uc-items-wrapper">
    {{put_items()}}
  </div>
</div>