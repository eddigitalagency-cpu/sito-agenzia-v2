{{ ucfunc("put_docready_start") }}
		
  {% set itemsForJs = get_items() %}  
  var itemsArray = {{itemsForJs|json_encode|raw}};
  var strJsonAttributes = {{put_attributes_json()}};
  var objAttributes = JSON.parse(strJsonAttributes);
   
  var options = {
    items: itemsArray,
    widgetsOptions: objAttributes,
  }
  
  var scrollMarquee = new ueScrollMarquee();

  scrollMarquee.init(options);
    	
{{ ucfunc("put_docready_end") }}